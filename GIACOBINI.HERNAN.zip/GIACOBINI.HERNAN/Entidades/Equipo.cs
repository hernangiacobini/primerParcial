﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        private const int cantidadMaximaJugadores;
        private int directorTecnico;
        private List<Jugador> jugadores;
        private int nombre;

        private Equipo()
        {
            
        }

        public Equipo(string nombre)
        {
           
        }

        public DirectorTecnico DirectorTecnico
        {
            set
            {
            }
        }

        public string Nombre
        {
            get
            {
                
            }
        }

        public explicit operator string(Equipo e)
        {

        }

        public static bool operator !=(Equipo e,Jugador j)
        {
        }

        public static Equipo operator +(Equipo e, Jugador j)
        {
        }

        public static bool operator ==(Equipo e, Jugador j)
        {
        }

        public bool ValidarEquipo(Equipo e)
        {
            
        }
    }
}

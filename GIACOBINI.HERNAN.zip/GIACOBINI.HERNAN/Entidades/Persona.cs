﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        private string apellido;
        private int dni;
        private int edad;
        private string nombre;

        public string Apellido
        {
            get
            {
            }
        }

        public int Dni
        {
            get
            {
            }
        }

        public int Edad
        {
            get
            {
            }
        }

        public string Nombre
        {
            get
            {
            }
        }

        public abstract string Mostrar()
        {
            StringBuilder mostrarPersona;
            mostrarPersona=new StringBuilder();
            return mostrarPersona.AppendFormat("Apellido: {0}, Nombre: {1}, DNI: {2}, Edad{3}", 
                                                this.apellido, this.nombre, this.dni, this.edad).ToString();
        }

        public abstract Persona(string nombre, string apellido, int edad, int dni)
        {
        }

        public abstract bool ValidadAptitud();
        
    }
}

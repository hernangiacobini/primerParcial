﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador:Persona
    {
        private float altura;
        private float peso;
        private Posicion posicion;

        public float Altura
        {
            get
            {
            }
        }

        public float Peso
        {
            get
            {
            }
        }

        public Posicion Posicion
        {
            get
            {
            }
        }

        public override Jugador(string nombre, string apellido, int edad, int dni, float peso, float altura, Posicion posicion)

        public string Mostrar()
        {
        }

        public bool ValidarAptitud()
        {
        }

        public bool ValidarEstadoFisico()
        {
        }
    }
}
